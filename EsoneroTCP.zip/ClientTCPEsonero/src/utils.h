#ifndef UTILS_H_
#define UTILS_H_

#define PORT 27015
#define MAXDIM 512
#define ADDRESS "127.0.0.1"
#define NO_ERROR 0

void clearwinsock() {
#if defined WIN32
	WSACleanup();
#endif
}

void errorhandler(char *errorMessage) {
	printf("%s", errorMessage);
}

struct values {
	char symbol;
	float val1;
	float val2;
};

#endif /* UTILS_H_ */
