#if defined WIN32
#include <winsock.h>
#else
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#define closesocket close
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <float.h>
#include <math.h>
#include "utils.h"


struct values tokenizeValues(char operation[]){
	struct values val;
	int i=2;
	int j=0;
	int k=0;
	char firstValue[MAXDIM];
	char secondValue[MAXDIM];
	val.symbol = operation[0];

	if(val.symbol == '='){
		return val;
	}
	else{
		while(operation[i]!=' '){
			firstValue[j]=operation[i];
			i++;
			j++;
		}
		firstValue[j] = '\0';
		i++;

		while(operation[i]!='\0'){
			secondValue[k]=operation[i];
			i++;
			k++;
		}
		secondValue[k] = '\0';
		val.val1 = atoi(firstValue);
		val.val2 = atoi(secondValue);
		return val;
	}
}

int checkString(char operation[]){
	int i = 3;
	int j = 1;

	if(operation[0] == '='){
		while(operation[j] == ' '){ //we allow the user to close the connection using a string which is composed by '=' followed by blankspaces or followed by nothing
			j++;
		}
		if(((int)operation[j]) == 10){
			return 1;
		}
		else{
			return 0;
		}
	}

	else if(((operation[0] == '+') || (operation[0] == '-') || (operation[0] == '*') || (operation[0] == '/'))//checking if the first position is a symbol,
			&& (isspace(operation[1])) && (isdigit(operation[2]))){ 										 //then if we have a blankspace and a number
		while((isdigit(operation[i]))){
			i++;

		}
		if((isspace(operation[i])) && (isdigit(operation[i+1]))){ //only one space allowed between symbol and first value and between the values
			i = i+2;
			while((isdigit(operation[i]))){// in this case, we do not allow blankspaces after the second value because it doesn't fit the operation structure
						i++;
					}
			if(((int)operation[i]) == 10){ //transforming the last character into his ASCII code to make possible to check if it is '\n'
				return 1;
			}
			else{
				return 0;
			}
		}
		else{
			return 0;
		}
	}
	else{
		return 0;
	}
}





int main(int argc, char *argv[]) {
	//...
#if defined WIN32
	// Initialize Winsock
	WSADATA wsa_data;
	int result = WSAStartup(MAKEWORD(2,2), &wsa_data);
	if (result != NO_ERROR) {
		printf("Error at WSAStartup()\n");
		return 0;
	}
#endif
    int client_socket;
    struct sockaddr_in cad;
    memset(&cad, 0, sizeof(cad));
    char operation[MAXDIM];
    struct values values;
    float res = 0;
    float integerRes = 0;

    client_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
    if(client_socket<0){
        errorhandler("socket creation failed \n");
        closesocket(client_socket);
        clearwinsock();
        return -1;
    }

    cad.sin_family = AF_INET;

   	if (argc > 1) {
    	cad.sin_addr.s_addr = inet_addr(argv[1]);
    	cad.sin_port = htons(atoi(argv[2]));
    }
   	else{
   	    cad.sin_addr.s_addr = inet_addr( ADDRESS );
   	    cad.sin_port = htons( PORT );
   	}

    if(connect(client_socket, (struct sockaddr *)&cad, sizeof(cad))<0){
        errorhandler("Failed to connect \n");
        closesocket(client_socket);
        clearwinsock();
        return -1;
    }

   	while(1){
   		printf("Operation format: symbol value value (Ex. + 3 2)\n"); //even if we're using floats, user has to use integer values for the operations
   		printf("Insert an operation: ");
   		fgets(operation,sizeof(operation),stdin); //using fgets because scanf causes problems with strings
   		if(checkString(operation) == 1){
   			values = tokenizeValues(operation); //tokenization of the operation inserted by the user
   	   		if(values.symbol == '='){ //checking if the user wants to close the connection
   		        if((send(client_socket,(struct values*)&values, sizeof(struct values), 0)) < 0){
   		           errorhandler("send() failed or connection closed prematurely");
   		           closesocket(client_socket);
   		           clearwinsock();
   		           return -1;
   		         }
   		    	closesocket(client_socket);
   		    	clearwinsock();
   		    	return 0;
   	   		}

   	   		else if((values.val1<10000) && (values.val2<10000)){ //we impose a limit on the values as suggested, avoiding results greater than MAX_FLOAT
   		        if((send(client_socket,(struct values*)&values, sizeof(struct values), 0)) < 0){
   		           errorhandler("send() failed or connection closed prematurely");
   		           closesocket(client_socket);
   		           clearwinsock();
   		           return -1;
   		         }

   	            if((recv(client_socket,(float*)&res, sizeof(float), 0)) <= 0){
   	               errorhandler("recv() failed or connection closed prematurely");
   	               closesocket(client_socket);
   	               clearwinsock();
   	               return -1;
   	             }

   	            if(res == FLT_MAX){
   	            	printf("Invalid values, dividing by zero\n"); //managing the division by zero with an error message
   	            }
   	            else{
   	   	            if(modff(res, &integerRes)>0){
   	   	            	printf("Result: %f\n", res);
   	   	            }
   	   	            else{
   	   	            	printf("Result: %d\n", (int)integerRes); //if there are no numbers after the . in the result, we print only the integer part
   	   	            }
   	            }

   	   		}
   	   		else{
   	   			printf("Values are too big\n");
   	   		}

   		}
   		else{
   			printf("Incorrect operation form\n");
   		}

   	}

} // main end
