
#if defined WIN32
#include <winsock.h>
#else
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#define closesocket close
#endif

#include <stdio.h>
#include <stdlib.h>
#include "utils.h"
#include <string.h>
#include <float.h>




float add(float val1, float val2){
	return val1+val2;
}

float mult(float val1, float val2){
	return val1*val2;
}

float sub(float val1, float val2){
	return val1-val2;
}

float division(float val1, float val2){ //using floats to avoid problems with divisions like 4/5
	if(val2!=0){
		return val1/val2;
	}
	else{
		return FLT_MAX; //returning FLOAT_MAX as an error value to the client if dividing by zero, as a sort of "infinite" value
	}
}






int main(int argc, char *argv[]) {
	//...
#if defined WIN32
	// Initialize Winsock
	WSADATA wsa_data;
	int result = WSAStartup(MAKEWORD(2,2), &wsa_data);
	if (result != NO_ERROR) {
		printf("Error at WSAStartup()\n");
		return 0;
	}
#endif



	int server_socket;
    struct sockaddr_in sad;
    int qlen = 5;
    struct sockaddr_in cad;
    struct values values;
    int client_socket;
    int client_len;
    float res = 0; //result of the operations



    server_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
    if(server_socket< 0) {
        errorhandler("socket creation failed \n");
        return -1;
    }

    sad.sin_family = AF_INET;

   	if (argc > 1) {
    	sad.sin_addr.s_addr = inet_addr( argv[1]);
    	sad.sin_port = htons(atoi(argv[2]));
    }
   	else{
   	    sad.sin_addr.s_addr = inet_addr( ADDRESS );
   	    sad.sin_port = htons( PORT );
   	}


    if(bind( server_socket , (struct sockaddr *) &sad, sizeof (sad))<0){
        errorhandler(("bind() failed \n"));
        closesocket(server_socket);
        return -1;
    }

    if(listen(server_socket, qlen) < 0){
        errorhandler("listen() failed \n");
        closesocket(server_socket);
        return -1;
    }

    printf("Waiting for a client to connect...\n");
    while(1){
        client_len = sizeof(cad);
        int flag = 0; //flag used to manage the '=' symbol
        if((client_socket=accept(server_socket, (struct sockaddr *) &cad, &client_len))<0){
            errorhandler("accept() failed \n");
            closesocket(server_socket);
            clearwinsock();
            return -1;
        }
        printf("Connection established with %s:%d\n", inet_ntoa(cad.sin_addr), cad.sin_port);
        while(flag == 0){
            if((recv(client_socket,(struct values*)&values, sizeof(struct values), 0)) <= 0){
               errorhandler("recv() failed or connection closed prematurely \n"); //if a client connects and then closes without an '=' symbol, we have an
               flag = 1;														  //error message, put the flag on 1 and do nothing
             }
            else{

                if(values.symbol == '='){
                    flag = 1;
                }
                else{

                	switch(values.symbol){

                	case '+':
                		res = add(values.val1, values.val2);
                		break;

                	case '-':
                		res = sub(values.val1, values.val2);
                		break;

                	case '*':
                		res = mult(values.val1, values.val2);
                		break;

                	case '/':
                		res = division(values.val1, values.val2);
                		break;

                	}

                    if(send(client_socket, (float*)&res, sizeof(float), 0) < 0){ //if there's a send failure, we got an error message, get out of while and close
                        errorhandler("send() sent a different number of bytes \n"); //the client socket
                        flag = 1;
                    }
                }
            }
        }
        	closesocket(client_socket); //closing the client socket but the server keeps listening for new client connection requests
    }
	closesocket(server_socket);
	clearwinsock();
	return 0;

}// main end


